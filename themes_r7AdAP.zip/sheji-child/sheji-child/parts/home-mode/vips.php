<?php
if (is_site_shop_open()): 
$home_mode_vip = _cao('home_vip_mod');
?>
<div class="section pt-0">
<div class="vip-container">
  <div class="vip-article-header">
    <h1 class="vip-article-title center" style="margin-top:0px;">VIP</h1>
    <div class="vip-desc"> 升级VIP， 享受更好的下载体验！ </div>
  </div>
  <div class="vip-wrapper">
    <div class="vip-content clearfix">
      <div class="vip-item item-1">
        <h6 style="background:<?php echo $home_mode_vip['_color'];?>">注册会员</h6>
        <span class="price">28<small><?php echo _cao('site_money_ua')?></small></span>
        <p class="border-decor"><span>永久</span></p>
        <?php echo $home_mode_vip['desc'];?>
        <?php if (is_user_logged_in()) : ?>
        <a href="<?php echo esc_url(home_url('/user?action=vip'));?>" class="btn btn-small signin-loader" style="background:<?php echo $item['_color'];?>"><i class="fa fa-unlink"></i> 立即升级</a>
        <?php else: ?>
        <a class="btn btn-small signin-loader login-btn btn-sm primary" style="background:<?php echo $home_mode_vip['_color'];?>"><i class="fa fa-user"></i> 登录购买</a>
        <?php endif; ?>
      </div>
      <?php foreach ( $home_mode_vip['vip_group'] as $item ) : ?>
      <div class="vip-item">
        <h6 style="background:<?php echo $item['_color'];?>"><?php echo $item['_time'];?></h6>
        <span class="price"><?php echo $item['_price'];?><small><?php echo _cao('site_money_ua')?></small></span>
        <p class="border-decor"><span><?php echo $item['_time'];?></span></p>
        <?php echo $item['_desc'];?>
        <?php if (is_user_logged_in()) : ?>
        <a href="<?php echo esc_url(home_url('/user?action=vip'));?>" class="btn btn-small signin-loader" style="background:<?php echo $item['_color'];?>"><i class="fa fa-unlink"></i> 立即升级</a>
        <?php else: ?>
        <a class="btn btn-small signin-loader login-btn btn-sm primary" style="background:<?php echo $item['_color'];?>"><i class="fa fa-user"></i> 登录购买</a>
        <?php endif; ?>
        
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  </div>
  
  
	
</div>
<?php endif; ?>