<?php
	$mode_banner = _cao('mode_banner');
	if (is_array($mode_banner) && isset($mode_banner['bgimg']) && _cao('is_footer_banner') ) : ?>

	<div class="custom_style module parallax">
		<img class="jarallax-img lazyload" data-srcset="<?php echo $mode_banner['bgimg']; ?>" data-sizes="auto" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" alt="">
		<section class="wrapper">
        <section class="custom_desc wow animated">
        <i class="fa fa-briefcase" aria-hidden="true"></i>
			<span>
				<?php echo wp_kses( $mode_banner['text'], array(
					'br' => array(),
				) ); ?>
			</span>
            </section>
            <section class="custom_btn">
			<?php if ( $mode_banner['primary_text'] != '' ) : ?>
				<a<?php echo _target_blank(); ?> class="more home_button wow animated" href="<?php echo esc_url( $mode_banner['primary_link'] ); ?>"><span><?php echo esc_html( $mode_banner['primary_text'] ); ?></span></a>
			<?php endif; ?>
			<?php if ( $mode_banner['secondary_text'] != '' ) : ?>
				<a<?php echo _target_blank(); ?> class="custom home_button wow bounceInRight animated" href="<?php echo esc_url( $mode_banner['secondary_link'] ); ?>"><span><?php echo esc_html( $mode_banner['secondary_text'] ); ?></span></a>
			<?php endif; ?>
            </section>
		</section>
	</div>
    <div class="clear"></div>
	<?php endif; ?>
</body>
</html>