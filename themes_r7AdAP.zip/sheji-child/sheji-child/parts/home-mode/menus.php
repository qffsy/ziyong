<?php
$home_menu_text_data = _cao('home_menu_text_data');
?>
<?php if (_cao('home_menu_text')) : ?>
<div class="html-box"><div class="shejisige">
<div class="container">
    <div class="home-division">
      <ul>
        <li><div class="item item_3"><a href="<?php echo $home_menu_text_data['hot_first_link'];?>" target="_blank">
          <div class="item-thumb"><i class="ri-medal-2-line"></i></div>
          <h3><?php echo $home_menu_text_data['hot_first_text'];?> <span class="go">go<i class="ico-go"></i></span> </h3>
          <p><?php echo $home_menu_text_data['hot_first_desc'];?></p>
        </a></div></li>
        <li><div class="item item_1"><a href="<?php echo $home_menu_text_data['hot_secondary_link'];?>" target="_blank">
          <div class="item-thumb"> <i class="ri-projector-line"></i> </div>
          <h3><?php echo $home_menu_text_data['hot_secondary_text'];?><span class="go">go<i class="ico-go"></i></span></h3>
          <p><?php echo $home_menu_text_data['hot_secondary_desc'];?></p>
        </a></div></li>
        <li><div class="item item_2"><a href="<?php echo $home_menu_text_data['hot_three_link'];?>" target="_blank">
          <div class="item-thumb"> <i class="ri-vip-crown-2-line"></i> </div>
          <h3><?php echo $home_menu_text_data['hot_three_text'];?><span class="go">go<i class="ico-go"></i></span></h3>
          <p><?php echo $home_menu_text_data['hot_three_desc'];?></p>
        </a></div></li>
  <li><div class="item item_2"><a href="<?php echo $home_menu_text_data['hot_four_link'];?>" target="_blank">
          <div class="item-thumb"> <i class="ri-exchange-cny-line"></i> </div>
          <h3><?php echo $home_menu_text_data['hot_four_text'];?><span class="go">go<i class="ico-go"></i></span></h3>
          <p><?php echo $home_menu_text_data['hot_four_desc'];?></p>
        </a></div></li>
        <li class="li_4"><div class="item item_4"><a href="<?php echo $home_menu_text_data['hot_five_link'];?>" target="_blank">
          <div class="item-thumb"> <i class="ri-wechat-2-line"></i></div>
          <h3><?php echo $home_menu_text_data['hot_five_text'];?><span class="go">go<i class="ico-go"></i></span></h3>
          <p><?php echo $home_menu_text_data['hot_five_desc'];?></p>
        </a></div></li>
      </ul>
    </div>
  </div> </div></div>
<?php endif; ?>  