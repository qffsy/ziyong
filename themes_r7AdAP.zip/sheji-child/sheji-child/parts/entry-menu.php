<div class="post-list-meta-box">
                        <div class="post-list-meta">
                          <?php if (_cao('grid_is_views',true)) : ?>
    <li class="post-list-meta-views"><?php echo '<i class="fa fa-eye"></i> '._get_post_views();?></li>
    <?php endif; ?>
    <?php if (_cao('grid_is_coments',false)) : ?>
    <li class="post-list-meta-comment"><?php echo _get_post_comments();?></li>
    <?php endif; ?>
                        </div>
                        <div class="post-list-cat b2-radius">
                        
                          <a target="_blank" class="post-list-cat-item b2-radius" style="background-color:#2196F3;" rel="category">
                  <?php
$category = get_the_category();
echo $category[0]->cat_name;
?>             </a>
                 
                        
                        </div>
    </div>