<?php
$sucaihu_ui_float_hongbao = _cao('sucaihu_ui_float_hongbao');
$sucaihu_ui_float_kefu = _cao('sucaihu_ui_float_kefu');
$sucaihu_ui_float_diylj = _cao('sucaihu_ui_float_diylj');
$sucaihu_ui_float_full = _cao('sucaihu_ui_float_full');
$sucaihu_ui_float_tgzq = _cao('sucaihu_ui_float_tgzq');
?>
<!--跟随样式开始-->
<link rel="stylesheet" href="//at.alicdn.com/t/font_1629860_b42wmttio0e.css"  type='text/css' media='all'>
<div class="rightList bar-v2">
  <ul class="sidebar">
    <?php if ($sucaihu_ui_float_hongbao['bgimg']) : ?>
    <li class="vip"> <a href="/user?action=charge" target="_blank" data-block="666" data-position="1"> <i class="iconfont iconhuiyuan"></i> <span>特惠红包</span>
      <div class="left-box"> <img src="<?php echo esc_url( @$sucaihu_ui_float_hongbao['bgimg'] ); ?>" alt=""> </div>
      </a> </li>
    <?php endif; ?>
    <?php if (_cao('sucaihu_ui_float_qiandao')) : ?>
    <li class="sign-in user-sign-in "> <a class="click-qiandao" href="javascript:void(0);" etap="to_top" title="打卡签到"> <i class="iconfont iconqiandao"></i> <span>签到</span> </a> </li>
    <?php endif; ?>
    <?php if (_cao('sucaihu_ui_float_kefu_open')) : ?>
    <?php if (_cao('sucaihu_ui_float_kefu')) : ?>
    <li class="customer-service"> <a class="custom-w" data-block="666" data-position="4" data-ext-mark="custom-03"> <i class="iconfont iconhtmal5icon31"></i> <span>客服</span> </a>
      <div class="service-box">
        <div class="service-con">
          <?php if ($sucaihu_ui_float_kefu['sucaihu_ui_float_kfqun']) : ?>
          <a href="//shang.qq.com/wpa/qunwpa?idkey=<?php echo $title = ($sucaihu_ui_float_kefu['sucaihu_ui_float_kfqun']); ?>" target="_blank" rel="nofollow"> 官方QQ群 <i class="iconfont icon-cebianlan"></i> </a>
          <?php endif; ?>
          <?php if ($sucaihu_ui_float_kefu['sucaihu_ui_float_kffaq']) : ?>
          <a data-ext-mark="custom-01" href="<?php echo $title = ($sucaihu_ui_float_kefu['sucaihu_ui_float_kffaq']); ?>" target="_blank"> 常见问题 FAQ <i class="iconfont icon-cebianlan"></i> </a>
          <?php endif; ?>
          <?php if ($sucaihu_ui_float_kefu['sucaihu_ui_float_kfqq']) : ?>
          <div class="custom-box">
            <p>在线客服</p>
            <a data-ext-mark="custom-02" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $title = ($sucaihu_ui_float_kefu['sucaihu_ui_float_kfqq']); ?>&site=qq&menu=yes" rel="nofollow"
                        class="btn-contact custom-w"> 点我联系 </a> </div>
          <?php endif; ?>
          <?php if ($sucaihu_ui_float_kefu['sucaihu_ui_float_gzsj']) : ?>
          <div class="custom-tel">
            <p> 工作时间: <?php echo $title = ($sucaihu_ui_float_kefu['sucaihu_ui_float_gzsj']); ?> </p>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </li>
    <?php endif; ?>
    <?php endif; ?>
    <?php if ($sucaihu_ui_float_diylj['sucaihu_ui_float_diy_url']) : ?>
    <li class="twinkle-point"> <a href="<?php echo $title = ($sucaihu_ui_float_diylj['sucaihu_ui_float_diy_url']); ?>" class="update-log" id="update-log-click" data-block="666" data-position="6" target="_blank"> <i class="iconfont icongengxin"> </i> <span>更新<br>
      日历</span> </a> </li>
    <?php endif; ?>
    <?php if (_cao('sucaihu_ui_float_dark')) : ?>
    <li class="twinkle-point"> <a class="rollbar-item tap-dark" href="javascript:void(0);" etap="tap-dark" title="夜间模式"> <i class="iconfont iconbrightness-half"></i> <span>暗黑<br>
      模式</span> </a> </li>
    <?php endif; ?>
    <?php if (_cao('sucaihu_ui_float_full')) : ?>
    <li class="client"> <a class="float-border float-text" href="javascript:void(0);" etap="to_full" title="点击全屏"> <i class="iconfont iconquanping"></i> <span>全屏</span> </a> </li>
    <?php endif; ?>
    <?php if (_cao('sucaihu_ui_float_zhishu')) : ?>
    <li class="customer-service"> <a class="update-log" id="update-log-click" data-block="666" data-position="6"
			rel="nofollow"> <i class="right-icon log-icon"> </i> <span> 本站 <br>
      指数 </span> </a>
      <div class="service-box">
        <div class="service-con">
          <div class="custom-num">
            运营天数：<?php echo floor((time()-strtotime("2019-04-13"))/86400); ?>+
          </div>
          <div class="custom-num">
            资源总数：
              <?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?>+
            
          </div>
          <div class="custom-num">
           用户总数：
              <?php $users = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users"); echo $users; ?>+
           
          </div>
          <div class="custom-num">
            今日更新：<?php echo WeeklyUpdate();?>+
          </div>
          <div class="custom-num">
          访问次数：<?php echo all_view(); ?>+
          </div>
          <div class="custom-num">
          本周更新：
              <?php get_week_post_count(); ?>+
          </div>
          <div class="custom-num">
             最后更新：
              <?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j', strtotime($last[0]->MAX_m));echo $last; ?>
          </div>
        </div>
      </div>
    </li>
	<?php endif; ?>
    <?php if ($sucaihu_ui_float_tgzq['sucaihu_ui_float_tgzq_url']) : ?>
    <li class="recruit"> <a href="<?php echo $title = ($sucaihu_ui_float_tgzq['sucaihu_ui_float_tgzq_url']); ?>" rel="nofollow" data-block="666"
            data-position="8" target="_blank"> <i class="iconfont iconzhifeiji"></i> <span>投稿<br>
      赚钱</span> </a> </li>
    <?php endif; ?>
  </ul>
  <div class="rollbar">
    <div class="Top" style="display: block;"  etap="to_top" title="返回顶部"> <i class="iconfont icontop"></i> <span class="common-gradient"></span> </div>
  </div>
</div>
<?php if (_cao('sucaihu_ui_float_wapqq')) : ?>
<!--手机QQ跟随-->
<div class="suspend">
  <dl>
    <a href="mqqwpa://im/chat?chat_type=wpa&uin=<?php echo $title = ($sucaihu_ui_float_kefu['sucaihu_ui_float_kfqq']); ?>&version=1&src_type=web&web_src=sucaihu"></a>
  </dl>
</div>
<!--手机QQ跟随-->
<?php endif; ?>
<?php if (_cao('sucaihu_ui_float_wap1')) : ?>
<!--手机跟随样式1-->
<div id="foot-memu" class="aini_foot_nav">
  <ul>
    <li> <a href="/" class="foothover"> <i class="nohover iconfont iconhome_light"></i>
      <p>首页</p>
      </a> </li>
    <li> <a class="click-qiandao" href="javascript:void(0);" etap="to_top" title="打卡签到"> <i class="nohover iconfont iconqiandao"></i>
      <p>签到</p>
      </a> </li>
    <li class="aini_zjbtn"> <a href="<?php echo $title = ($sucaihu_ui_float_tgzq['sucaihu_ui_float_tgzq_url']); ?>" rel="nofollow" data-block="666" data-position="8" target="_blank"> <em class="bg_f b_ok"></em> <span class="bg_f"> <i class="iconfont foot_btn f_f iconjiahao"></i> </span> </a> </li>
    <li> <a class="rollbar-item tap-dark" href="javascript:void(0);" etap="tap-dark" title="夜间模式"> <i class="nohover iconfont iconbrightness-half"></i>
      <p>切换</p>
      </a> </li>
    <li> <a href="mqqwpa://im/chat?chat_type=wpa&uin=<?php echo $title = ($sucaihu_ui_float_kefu['sucaihu_ui_float_kfqq']); ?>&version=1&src_type=web&web_src=srcidct"> <i class="nohover iconfont iconcomment"></i>
      <p>客服</p>
      </a> </li>
  </ul>
</div>
<!--手机跟随样式1-->
<?php endif; ?>
<!--跟随样式结束-->